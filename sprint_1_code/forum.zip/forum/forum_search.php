<?php
require_once 'forum_common.php';

$pageTitle = 'Search';
$currentId = current_user_id();
$keyword = trim($_GET['keyword'] ?? '');

$users = [];
$posts = [];

if ($keyword !== '') {
    $like = '%' . $keyword . '%';

    $sql = "SELECT user_id, username, nickname, student_level
            FROM users
            WHERE user_id != ?
              AND (username LIKE ? OR nickname LIKE ?)
            ORDER BY nickname, username
            LIMIT 50";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iss", $currentId, $like, $like);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
    $stmt->close();

    $sql = "SELECT p.*, u.username, u.nickname
            FROM forum_posts p
            JOIN users u ON p.user_id = u.user_id
            WHERE p.is_deleted = 0
              AND p.title LIKE ?
            ORDER BY p.created_at DESC
            LIMIT 50";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $like);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        if (can_view_post($conn, $row, $currentId)) {
            $posts[] = $row;
        }
    }
    $stmt->close();
}

include 'forum_header.php';
?>

<div class="card">
    <h2 style="margin-top:0;">Search Community</h2>
    <form method="get" action="forum_search.php">
        <input type="text" name="keyword" placeholder="Search users or post titles..." value="<?= h($keyword) ?>">
        <button class="btn btn-primary" type="submit">Search</button>
    </form>
    <div class="meta">You can search by username, nickname, or post title.</div>
</div>

<?php if ($keyword !== ''): ?>
    <div class="card">
        <h3 style="margin-top:0;">User Results</h3>

        <?php if (empty($users)): ?>
            <div class="meta">No users found.</div>
        <?php else: ?>
            <?php foreach ($users as $user): ?>
                <?php $alreadyFollowing = is_following($conn, $currentId, (int)$user['user_id']); ?>
                <div class="row-between" style="padding: 14px 0; border-bottom: 1px solid #e5e7eb;">
                    <div>
                        <a class="link-user" href="forum_profile.php?user_id=<?= (int)$user['user_id'] ?>">
                            <?= h($user['nickname'] ?: $user['username']) ?>
                        </a>
                        <div class="meta">
                            @<?= h($user['username']) ?>
                            <?php if (!empty($user['student_level'])): ?>
                                &middot; <?= h($user['student_level']) ?>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div style="display:flex; gap:10px; flex-wrap:wrap;">
                        <a class="btn btn-secondary" href="forum_profile.php?user_id=<?= (int)$user['user_id'] ?>">
                            View Profile
                        </a>

                        <a class="btn btn-dark" href="forum_inbox.php?user_id=<?= (int)$user['user_id'] ?>">
                            Message
                        </a>

                        <?php if ($alreadyFollowing): ?>
                            <a class="btn btn-secondary" href="forum_follow_action.php?user_id=<?= (int)$user['user_id'] ?>&action=unfollow&redirect=search&keyword=<?= urlencode($keyword) ?>">
                                Unfollow
                            </a>
                        <?php else: ?>
                            <a class="btn btn-primary" href="forum_follow_action.php?user_id=<?= (int)$user['user_id'] ?>&action=follow&redirect=search&keyword=<?= urlencode($keyword) ?>">
                                Follow
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <div class="card">
        <h3 style="margin-top:0;">Post Results</h3>

        <?php if (empty($posts)): ?>
            <div class="meta">No posts found.</div>
        <?php else: ?>
            <?php foreach ($posts as $post): ?>
                <div style="padding: 16px 0; border-bottom: 1px solid #e5e7eb;">
                    <div class="row-between">
                        <div style="flex:1;">
                            <h4 style="margin:0 0 8px;">
                                <a href="forum_post_view.php?post_id=<?= (int)$post['post_id'] ?>" style="text-decoration:none; color:#111827;">
                                    <?= h($post['title'] ?: 'Untitled Post') ?>
                                </a>
                            </h4>

                            <div class="meta">
                                By
                                <a class="link-user" href="forum_profile.php?user_id=<?= (int)$post['user_id'] ?>">
                                    <?= h($post['nickname'] ?: $post['username']) ?>
                                </a>
                                &middot; <?= h($post['visibility']) ?> &middot; <?= h($post['created_at']) ?>
                            </div>

                            <?php if (!empty($post['content'])): ?>
                                <div class="post-content">
                                    <?= h(mb_substr($post['content'], 0, 180)) ?>
                                    <?= mb_strlen($post['content']) > 180 ? '...' : '' ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div style="display:flex; gap:10px; flex-wrap:wrap;">
                            <a class="btn btn-secondary" href="forum_post_view.php?post_id=<?= (int)$post['post_id'] ?>">
                                View Post
                            </a>
                            <a class="btn btn-secondary" href="forum_profile.php?user_id=<?= (int)$post['user_id'] ?>">
                                View Author
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
<?php endif; ?>

<?php include 'forum_footer.php'; ?>

<?php
require_once 'forum_common.php';
$pageTitle = 'Create Post';
$userId = current_user_id();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    $visibility = $_POST['visibility'] ?? 'public';

    $allowed = ['public', 'followers_only', 'friends_only', 'private'];

    if ($content === '') {
        $error = 'Please enter post content.';
    } elseif (!in_array($visibility, $allowed, true)) {
        $error = 'Invalid visibility.';
    } else {
        $sql = "INSERT INTO forum_posts (user_id, title, content, visibility)
                VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("isss", $userId, $title, $content, $visibility);

        if ($stmt->execute()) {
            $stmt->close();
            header('Location: forum.php?posted=1');
            exit;
        } else {
            $error = 'Failed to publish the post: ' . $conn->error;
            $stmt->close();
        }
    }
}

include 'forum_header.php';
?>

<div class="card">
    <h2 style="margin-top:0;">Create a New Post</h2>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= h($error) ?></div>
    <?php endif; ?>

    <form method="post" action="forum_post_create.php">
        <label>Title</label>
        <input type="text" name="title" maxlength="255" placeholder="Enter a title">

        <label>Content</label>
        <textarea name="content" rows="8" placeholder="Share your thoughts..."></textarea>

        <label>Visibility</label>
        <select name="visibility">
            <option value="public">Public</option>
            <option value="followers_only">Followers only</option>
            <option value="friends_only">Friends only</option>
            <option value="private">Private</option>
        </select>

        <button class="btn btn-primary" type="submit">Publish</button>
    </form>
</div>

<?php include 'forum_footer.php'; ?>

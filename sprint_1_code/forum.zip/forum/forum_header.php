<?php
require_once 'forum_common.php';
$currentUser = find_user($conn, current_user_id());
$unreadCount = unread_message_count($conn, current_user_id());

$currentPage = basename($_SERVER['PHP_SELF']);

function nav_active($page, $currentPage) {
    return $page === $currentPage ? 'subnav-link active' : 'subnav-link';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= h($pageTitle ?? 'Community') ?></title>
    <style>
        :root {
            --primary-green: #1b4332;
            --accent-green: #40916c;
            --soft-green-bg: #f2f7f5;
            --card-shadow: 0 10px 30px rgba(27, 67, 50, 0.08);
            --text-main: #2d3436;
            --text-light: #6d7d76;
        }

        body {
            margin: 0;
            padding: 0;
            background-color: var(--soft-green-bg);
            font-family: 'Segoe UI', Tahoma, sans-serif;
            color: var(--text-main);
        }

        .nav-header {
            width: 100%;
            height: 70px;
            background: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 50px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.05);
            position: fixed;
            top: 0;
            z-index: 1000;
            box-sizing: border-box;
        }
        .nav-logo {
            font-size: 22px;
            font-weight: bold;
            color: var(--primary-green);
            text-decoration: none;
        }
        .nav-links {
            display: flex;
            gap: 20px;
        }
        .nav-links a {
            text-decoration: none;
            color: #666;
            font-size: 14px;
            font-weight: 500;
            padding: 5px 12px;
            border-radius: 8px;
            transition: 0.3s;
        }
        .nav-links a:hover,
        .nav-links a.active {
            color: var(--primary-green);
            background: #f0f7f4;
        }

        .forum-subnav {
            margin-top: 70px;
            background: linear-gradient(135deg, #081c15 0%, #1b4332 100%);
            color: white;
            padding: 18px 50px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
        }
        .forum-subnav .left h1 {
            margin: 0;
            font-size: 1.8rem;
        }
        .forum-subnav .left p {
            margin: 6px 0 0;
            opacity: 0.9;
        }
        .forum-subnav .right {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            align-items: center;
        }

        .subnav-link {
            text-decoration: none;
            color: #123;
            background: #ffffff;
            padding: 10px 18px;
            border-radius: 999px;
            font-weight: 600;
            box-shadow: 0 4px 10px rgba(0,0,0,0.06);
            transition: 0.2s;
        }
        .subnav-link:hover {
            background: #eef2ff;
        }
        .subnav-link.active {
            background: #2563eb;
            color: #fff;
        }

        .forum-search-form {
            display: flex;
            gap: 8px;
            align-items: center;
            margin-left: 8px;
        }
        .forum-search-input {
            width: 220px;
            padding: 10px 14px;
            border-radius: 999px;
            border: none;
            outline: none;
            font-size: 14px;
        }
        .forum-search-btn {
            border: none;
            cursor: pointer;
            padding: 10px 16px;
            border-radius: 999px;
            background: #ffffff;
            color: #123;
            font-weight: 600;
        }
        .forum-search-btn:hover {
            background: #eef2ff;
        }

        .badge {
            display: inline-block;
            min-width: 18px;
            padding: 2px 6px;
            border-radius: 999px;
            background: #dc2626;
            color: #fff;
            font-size: 12px;
            text-align: center;
            margin-left: 6px;
        }

        .container {
            width: 90%;
            max-width: 1100px;
            margin: 24px auto 40px;
        }

        .card {
            background: #ffffff;
            border-radius: 20px;
            padding: 24px;
            box-shadow: var(--card-shadow);
            margin-bottom: 20px;
        }

        .row-between {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
        }

        .meta {
            color: var(--text-light);
            font-size: 14px;
            margin-bottom: 8px;
        }

        .post-content {
            white-space: pre-wrap;
            line-height: 1.7;
        }

        .btn {
            display: inline-block;
            padding: 10px 16px;
            border-radius: 999px;
            text-decoration: none;
            border: none;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
        }
        .btn-primary { background: #2563eb; color: white; }
        .btn-secondary { background: #e2e8f0; color: #111827; }
        .btn-danger { background: #dc2626; color: white; }
        .btn-dark { background: #111827; color: white; }

        textarea, input, select {
            width: 100%;
            box-sizing: border-box;
            padding: 10px 12px;
            border: 1px solid #cbd5e1;
            border-radius: 10px;
            margin-top: 6px;
            margin-bottom: 14px;
            font-family: inherit;
        }

        .comment {
            border-left: 3px solid #93c5fd;
            padding-left: 12px;
            margin-bottom: 16px;
        }

        .reply-tag {
            color: #2563eb;
            font-weight: bold;
        }

        .alert {
            padding: 10px 14px;
            border-radius: 10px;
            margin-bottom: 14px;
        }
        .alert-danger { background: #fee2e2; color: #991b1b; }
        .alert-info { background: #dbeafe; color: #1d4ed8; }
        .alert-warning { background: #fef3c7; color: #92400e; }

        .link-user {
            color: var(--primary-green);
            text-decoration: none;
            font-weight: 700;
        }
        .link-user:hover { text-decoration: underline; }

        .chat-layout {
            display: grid;
            grid-template-columns: 300px 1fr;
            gap: 20px;
        }

        .chat-sidebar {
            background: #fff;
            border-radius: 18px;
            box-shadow: var(--card-shadow);
            overflow: hidden;
        }

        .chat-contact {
            display: block;
            padding: 16px 18px;
            text-decoration: none;
            color: #222;
            border-bottom: 1px solid #eef2f7;
        }
        .chat-contact:hover,
        .chat-contact.active {
            background: #eef6f1;
        }

        .chat-window {
            background: #fff;
            border-radius: 18px;
            box-shadow: var(--card-shadow);
            display: flex;
            flex-direction: column;
            min-height: 600px;
        }

        .chat-header {
            padding: 18px 20px;
            border-bottom: 1px solid #eef2f7;
            font-weight: 700;
            color: var(--primary-green);
        }

        .chat-messages {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
            background: #f8fbf9;
        }

        .msg-row {
            display: flex;
            margin-bottom: 14px;
        }
        .msg-row.me {
            justify-content: flex-end;
        }

        .msg-bubble {
            max-width: 70%;
            padding: 12px 16px;
            border-radius: 18px;
            line-height: 1.5;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            background: #fff;
        }
        .msg-row.me .msg-bubble {
            background: #d7f3df;
        }

        .msg-time {
            font-size: 12px;
            color: #6b7280;
            margin-top: 6px;
        }

        .chat-input {
            padding: 16px 20px;
            border-top: 1px solid #eef2f7;
        }

        @media (max-width: 800px) {
            .nav-header { position: static; height: auto; padding: 16px 20px; flex-direction: column; }
            .nav-links { flex-wrap: wrap; justify-content: center; }
            .forum-subnav { margin-top: 0; padding: 18px 20px; }
            .chat-layout { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<nav class="nav-header">
    <a href="home.php" class="nav-logo">Word Garden</a>
    <div class="nav-links">
        <a href="home.php">Home</a>
        <a href="TED.php">TED Talk</a>
        <a href="ielts.php">IELTS</a>
        <a href="daily_talk.php">Daily Talk</a>
        <a href="reading.php">Reading</a>
        <a href="vocabulary.php">Vocabulary</a>
        <a href="calendar.php">Calendar</a>
        <a href="forum.php" class="active">Community</a>
        <a href="profile.php">Profile</a>
    </div>
</nav>

<div class="forum-subnav">
    <div class="left">
        <h1><?= h($pageTitle ?? 'Community') ?></h1>
        <p>Join discussions, follow learners, and keep in touch.</p>
    </div>

    <div class="right">
        <a class="<?= nav_active('forum.php', $currentPage) ?>" href="forum.php">Community</a>
        <a class="<?= nav_active('forum_post_create.php', $currentPage) ?>" href="forum_post_create.php">New Post</a>
        <a class="<?= nav_active('forum_friends.php', $currentPage) ?>" href="forum_friends.php">Friends</a>
        <a class="<?= nav_active('forum_following.php', $currentPage) ?>" href="forum_following.php">Following</a>
        <a class="<?= nav_active('forum_inbox.php', $currentPage) ?>" href="forum_inbox.php">
            Message<?php if ($unreadCount > 0): ?><span class="badge"><?= (int)$unreadCount ?></span><?php endif; ?>
        </a>

        <form class="forum-search-form" method="get" action="forum_search.php">
            <input class="forum-search-input" type="text" name="keyword" placeholder="Search users..." value="<?= h($_GET['keyword'] ?? '') ?>">
            <button class="forum-search-btn" type="submit">Search</button>
        </form>
    </div>
</div>

<div class="container">

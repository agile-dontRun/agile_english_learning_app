<?php
require_once 'forum_common.php';

$postId = (int)($_GET['post_id'] ?? 0);
$viewerId = current_user_id();
$error = '';

$sql = "SELECT p.*, u.username, u.nickname
        FROM forum_posts p
        JOIN users u ON p.user_id = u.user_id
        WHERE p.post_id = ? AND p.is_deleted = 0";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die('SQL prepare failed: ' . $conn->error);
}
$stmt->bind_param("i", $postId);
$stmt->execute();
$result = $stmt->get_result();
$post = $result->fetch_assoc();
$stmt->close();

if (!$post || !can_view_post($conn, $post, $viewerId)) {
    die('Post not found or not accessible.');
}

if ((int)$post['user_id'] === $viewerId) {
    $sql = "UPDATE forum_comments
            SET is_seen_by_post_author = 1
            WHERE post_id = ?
              AND user_id <> ?
              AND is_deleted = 0
              AND is_seen_by_post_author = 0";
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("ii", $postId, $viewerId);
        $stmt->execute();
        $stmt->close();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $content = trim($_POST['content'] ?? '');
    $parentCommentId = !empty($_POST['parent_comment_id']) ? (int)$_POST['parent_comment_id'] : null;
    $replyToUserId = !empty($_POST['reply_to_user_id']) ? (int)$_POST['reply_to_user_id'] : null;

    if ($content === '') {
        $error = 'Please enter a comment.';
    } else {
        $seen = ((int)$post['user_id'] === $viewerId) ? 1 : 0;

        $sql = "INSERT INTO forum_comments (post_id, user_id, parent_comment_id, reply_to_user_id, content, is_seen_by_post_author)
                VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            $error = 'Comment insert prepare failed: ' . $conn->error;
        } else {
            $stmt->bind_param("iiiisi", $postId, $viewerId, $parentCommentId, $replyToUserId, $content, $seen);
            if ($stmt->execute()) {
                $stmt->close();
                header('Location: forum_post_view.php?post_id=' . $postId);
                exit;
            } else {
                $error = 'Failed to save comment: ' . $stmt->error;
                $stmt->close();
            }
        }
    }
}

$sql = "SELECT c.*,
               u.username, u.nickname,
               ru.username AS reply_to_username,
               ru.nickname AS reply_to_nickname
        FROM forum_comments c
        JOIN users u ON c.user_id = u.user_id
        LEFT JOIN users ru ON c.reply_to_user_id = ru.user_id
        WHERE c.post_id = ? AND c.is_deleted = 0
        ORDER BY c.created_at ASC";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die('Comment query prepare failed: ' . $conn->error);
}
$stmt->bind_param("i", $postId);
$stmt->execute();
$commentsResult = $stmt->get_result();

$comments = [];
while ($row = $commentsResult->fetch_assoc()) {
    $comments[] = $row;
}
$stmt->close();

$pageTitle = $post['title'] ?: 'Post';
include 'forum_header.php';
?>

<div class="card">
    <div class="row-between">
        <div>
            <h1 style="margin-top:0;"><?= h($post['title'] ?: 'Untitled Post') ?></h1>
            <div class="meta">
                By
                <a class="link-user" href="forum_profile.php?user_id=<?= (int)$post['user_id'] ?>">
                    <?= h($post['nickname'] ?: $post['username']) ?>
                </a>
                &middot; <?= h($post['visibility']) ?> &middot; <?= h($post['created_at']) ?>
            </div>
        </div>

        <?php if ((int)$post['user_id'] !== $viewerId): ?>
            <a class="btn btn-secondary" href="forum_profile.php?user_id=<?= (int)$post['user_id'] ?>">Visit Profile</a>
        <?php endif; ?>
    </div>

    <?php if ($post['content'] !== ''): ?>
        <div class="post-content"><?= h($post['content']) ?></div>
    <?php endif; ?>
</div>

<div class="card">
    <h2>Leave a Comment</h2>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= h($error) ?></div>
    <?php endif; ?>

    <form method="post">
        <input type="hidden" name="parent_comment_id" id="parent_comment_id">
        <input type="hidden" name="reply_to_user_id" id="reply_to_user_id">

        <div id="replying_to_box" class="alert alert-info" style="display:none;"></div>

        <textarea name="content" rows="4" placeholder="Write a comment..."></textarea>
        <button class="btn btn-primary">Comment</button>
    </form>
</div>

<div class="card">
    <h2>Comments</h2>

    <?php foreach ($comments as $comment): ?>
        <div class="comment">
            <div class="row-between">
                <div>
                    <a class="link-user" href="forum_profile.php?user_id=<?= (int)$comment['user_id'] ?>">
                        <?= h($comment['nickname'] ?: $comment['username']) ?>
                    </a>

                    <?php if ($comment['reply_to_user_id']): ?>
                        <span class="reply-tag">@<?= h($comment['reply_to_nickname'] ?: $comment['reply_to_username']) ?></span>
                    <?php endif; ?>

                    <div class="meta"><?= h($comment['created_at']) ?></div>
                </div>

                <div style="display:flex; gap:8px;">
                    <button
                        class="btn btn-secondary reply-btn"
                        data-comment-id="<?= (int)$comment['comment_id'] ?>"
                        data-user-id="<?= (int)$comment['user_id'] ?>"
                        data-user-name="<?= h($comment['nickname'] ?: $comment['username']) ?>">
                        Reply
                    </button>

                    <?php if ((int)$comment['user_id'] === $viewerId): ?>
                        <a class="btn btn-danger" href="forum_delete_comment.php?comment_id=<?= (int)$comment['comment_id'] ?>&post_id=<?= (int)$postId ?>">
                            Delete
                        </a>
                    <?php endif; ?>
                </div>
            </div>

            <?php if ($comment['content'] !== ''): ?>
                <div><?= h($comment['content']) ?></div>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</div>

<?php include 'forum_footer.php'; ?>

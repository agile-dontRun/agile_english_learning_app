<?php
require_once 'forum_common.php';

$senderId = current_user_id();
$receiverId = (int)($_POST['receiver_id'] ?? 0);
$content = trim($_POST['content'] ?? '');

if ($receiverId <= 0 || $receiverId === $senderId) {
    header('Location: forum_inbox.php?user_id=' . $receiverId . '&error=invalid_receiver');
    exit;
}

if ($content === '') {
    header('Location: forum_inbox.php?user_id=' . $receiverId . '&error=empty');
    exit;
}

if (message_limit_reached($conn, $senderId, $receiverId)) {
    header('Location: forum_inbox.php?user_id=' . $receiverId . '&error=limit');
    exit;
}

$sql = "INSERT INTO private_messages (sender_id, receiver_id, content, is_read)
        VALUES (?, ?, ?, 0)";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    header('Location: forum_inbox.php?user_id=' . $receiverId . '&error=sql_prepare');
    exit;
}

$stmt->bind_param("iis", $senderId, $receiverId, $content);

if (!$stmt->execute()) {
    $stmt->close();
    header('Location: forum_inbox.php?user_id=' . $receiverId . '&error=send_failed');
    exit;
}

$stmt->close();

header('Location: forum_inbox.php?user_id=' . $receiverId . '&sent=1');
exit;
?>

<?php
require_once 'forum_common.php';

$currentId = current_user_id();
$otherId = (int)($_GET['user_id'] ?? 0);
$pageTitle = 'Messages';
$error = $_GET['error'] ?? '';
$sent = $_GET['sent'] ?? '';

$contacts = [];

$sql = "
    SELECT DISTINCT u.user_id, u.username, u.nickname
    FROM users u
    WHERE u.user_id IN (
        SELECT CASE
            WHEN uf.user_id_1 = ? THEN uf.user_id_2
            ELSE uf.user_id_1
        END
        FROM user_friendships uf
        WHERE uf.user_id_1 = ? OR uf.user_id_2 = ?

        UNION

        SELECT pm.sender_id
        FROM private_messages pm
        WHERE pm.receiver_id = ?

        UNION

        SELECT pm.receiver_id
        FROM private_messages pm
        WHERE pm.sender_id = ?
    )
    ORDER BY u.nickname, u.username
";
$stmt = $conn->prepare($sql);
$stmt->bind_param("iiiii", $currentId, $currentId, $currentId, $currentId, $currentId);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $contacts[] = $row;
}
$stmt->close();

$otherUser = null;
$messages = [];

if ($otherId > 0) {
    $otherUser = find_user($conn, $otherId);

    if ($otherUser) {
        $sql = "UPDATE private_messages
                SET is_read = 1
                WHERE sender_id = ? AND receiver_id = ? AND is_read = 0";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $otherId, $currentId);
        $stmt->execute();
        $stmt->close();

        $sql = "
            SELECT pm.*, su.username AS sender_username, su.nickname AS sender_nickname
            FROM private_messages pm
            JOIN users su ON pm.sender_id = su.user_id
            WHERE (
                (pm.sender_id = ? AND pm.receiver_id = ? AND pm.is_deleted_by_sender = 0)
                OR
                (pm.sender_id = ? AND pm.receiver_id = ? AND pm.is_deleted_by_receiver = 0)
            )
            ORDER BY pm.created_at ASC
        ";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iiii", $currentId, $otherId, $otherId, $currentId);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $messages[] = $row;
        }
        $stmt->close();
    }
}

include 'forum_header.php';
?>

<div class="chat-layout">
    <div class="chat-sidebar">
        <div style="padding:16px 18px; font-weight:700; color:#1b4332; border-bottom:1px solid #eef2f7;">
            Chats
        </div>

        <?php if (empty($contacts)): ?>
            <div style="padding:18px; color:#6d7d76;">No conversations yet.</div>
        <?php endif; ?>

        <?php foreach ($contacts as $contact): ?>
            <?php
            $contactUnread = 0;
            $sql = "SELECT COUNT(*) AS total
                    FROM private_messages
                    WHERE sender_id = ? AND receiver_id = ? AND is_read = 0 AND is_deleted_by_receiver = 0";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ii", $contact['user_id'], $currentId);
            $stmt->execute();
            $r = $stmt->get_result()->fetch_assoc();
            $contactUnread = (int)($r['total'] ?? 0);
            $stmt->close();

            $alreadyFollowing = is_following($conn, $currentId, (int)$contact['user_id']);
            ?>
            <div class="chat-contact <?= $otherId === (int)$contact['user_id'] ? 'active' : '' ?>" style="display:flex; justify-content:space-between; align-items:center; gap:10px;">
                <a href="forum_inbox.php?user_id=<?= (int)$contact['user_id'] ?>" style="text-decoration:none; color:inherit; flex:1;">
                    <div style="font-weight:700; color:#1b4332;">
                        <?= h($contact['nickname'] ?: $contact['username']) ?>
                        <?php if ($contactUnread > 0): ?>
                            <span class="badge"><?= $contactUnread ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="meta">@<?= h($contact['username']) ?></div>
                </a>

                <?php if ((int)$contact['user_id'] !== $currentId): ?>
                    <?php if ($alreadyFollowing): ?>
                        <a class="btn btn-secondary"
                           style="padding:6px 12px; font-size:12px; white-space:nowrap;"
                           href="forum_follow_action.php?user_id=<?= (int)$contact['user_id'] ?>&action=unfollow&redirect=inbox">
                            Unfollow
                        </a>
                    <?php else: ?>
                        <a class="btn btn-primary"
                           style="padding:6px 12px; font-size:12px; white-space:nowrap;"
                           href="forum_follow_action.php?user_id=<?= (int)$contact['user_id'] ?>&action=follow&redirect=inbox">
                            Follow
                        </a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="chat-window">
        <?php if ($otherUser): ?>
            <div class="chat-header">
                <?= h($otherUser['nickname'] ?: $otherUser['username']) ?>
            </div>

            <?php if ($error === 'limit'): ?>
                <div class="alert alert-warning" style="margin:16px;">
                    You can only exchange one message before becoming friends.
                </div>
            <?php elseif ($error === 'empty'): ?>
                <div class="alert alert-warning" style="margin:16px;">
                    Please enter a message.
                </div>
            <?php elseif ($error === 'send_failed'): ?>
                <div class="alert alert-danger" style="margin:16px;">
                    Message sending failed. Please try again.
                </div>
            <?php elseif ($error === 'sql_prepare'): ?>
                <div class="alert alert-danger" style="margin:16px;">
                    Database prepare failed. Please check table structure.
                </div>
            <?php elseif ($error === 'invalid_receiver'): ?>
                <div class="alert alert-danger" style="margin:16px;">
                    Invalid receiver.
                </div>
            <?php elseif ($sent === '1'): ?>
                <div class="alert alert-info" style="margin:16px;">
                    Message sent successfully.
                </div>
            <?php endif; ?>

            <div class="chat-messages" id="chatMessages">
                <?php foreach ($messages as $message): ?>
                    <div class="msg-row <?= ((int)$message['sender_id'] === $currentId) ? 'me' : '' ?>">
                        <div class="msg-bubble">
                            <?php if ($message['content'] !== ''): ?>
                                <div><?= h($message['content']) ?></div>
                            <?php endif; ?>

                            <div class="msg-time"><?= h($message['created_at']) ?></div>

                            <?php if ((int)$message['sender_id'] === $currentId): ?>
                                <div style="margin-top:8px;">
                                    <a class="btn btn-danger" style="padding:6px 12px; font-size:12px;"
                                       href="forum_delete_message.php?message_id=<?= (int)$message['message_id'] ?>&user_id=<?= (int)$otherUser['user_id'] ?>">
                                        Delete
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="chat-input">
                <form method="post" action="forum_message_send.php">
                    <input type="hidden" name="receiver_id" value="<?= (int)$otherUser['user_id'] ?>">
                    <textarea name="content" rows="3" placeholder="Type a message..."></textarea>
                    <button class="btn btn-primary" type="submit">Send</button>
                </form>
            </div>

            <script>
                const chatBox = document.getElementById('chatMessages');
                if (chatBox) {
                    chatBox.scrollTop = chatBox.scrollHeight;
                }
            </script>
        <?php else: ?>
            <div class="chat-header">Messages</div>
            <div style="padding:24px; color:#6d7d76;">
                Select a contact on the left to start or continue chatting.
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'forum_footer.php'; ?>

<?php
require_once 'forum_common.php';
$pageTitle = 'Community Forum';
$viewerId = current_user_id();

$sql = "SELECT p.*, u.username, u.nickname
        FROM forum_posts p
        JOIN users u ON p.user_id = u.user_id
        WHERE p.is_deleted = 0
        ORDER BY p.created_at DESC";
$result = $conn->query($sql);

$posts = [];
while ($row = $result->fetch_assoc()) {
    if (can_view_post($conn, $row, $viewerId)) {
        $posts[] = $row;
    }
}

include 'forum_header.php';
?>

<?php foreach ($posts as $post): ?>
    <div class="card">
        <div class="row-between">
            <div>
                <h3 style="margin:0 0 8px;">
                    <a href="forum_post_view.php?post_id=<?= (int)$post['post_id'] ?>" style="text-decoration:none;color:#111827;">
                        <?= h($post['title'] ?: 'Untitled Post') ?>
                    </a>
                </h3>
                <div class="meta">
                    By
                    <a class="link-user" href="forum_profile.php?user_id=<?= (int)$post['user_id'] ?>">
                        <?= h($post['nickname'] ?: $post['username']) ?>
                    </a>
                    &middot; <?= h($post['visibility']) ?> &middot; <?= h($post['created_at']) ?>
                </div>
            </div>

            <?php if ((int)$post['user_id'] === $viewerId): ?>
                <a class="btn btn-danger" href="forum_delete_post.php?post_id=<?= (int)$post['post_id'] ?>">Delete</a>
            <?php endif; ?>
        </div>

        <div class="post-content"><?= h(mb_substr($post['content'], 0, 260)) ?><?= mb_strlen($post['content']) > 260 ? '...' : '' ?></div>
    </div>
<?php endforeach; ?>

<?php include 'forum_footer.php'; ?>

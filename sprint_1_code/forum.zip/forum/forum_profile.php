<?php
require_once 'forum_common.php';

$viewerId = current_user_id();
$userId = (int)($_GET['user_id'] ?? $viewerId);
$user = find_user($conn, $userId);

if (!$user) {
    die('User not found.');
}

$isSelf = ($viewerId === $userId);
$isFollowing = is_following($conn, $viewerId, $userId);
$isFriend = are_friends($conn, $viewerId, $userId);

$sql = "SELECT COUNT(*) AS total FROM user_follows WHERE followed_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$followersCount = (int)($result->fetch_assoc()['total'] ?? 0);
$stmt->close();

$sql = "SELECT COUNT(*) AS total FROM user_follows WHERE follower_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$followingCount = (int)($result->fetch_assoc()['total'] ?? 0);
$stmt->close();

$sql = "SELECT COUNT(*) AS total
        FROM user_friendships
        WHERE user_id_1 = ? OR user_id_2 = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $userId, $userId);
$stmt->execute();
$result = $stmt->get_result();
$friendsCount = (int)($result->fetch_assoc()['total'] ?? 0);
$stmt->close();

$sql = "SELECT *
        FROM forum_posts
        WHERE user_id = ? AND is_deleted = 0
        ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

$posts = [];
while ($row = $result->fetch_assoc()) {
    if (can_view_post($conn, $row, $viewerId)) {
        $posts[] = $row;
    }
}
$stmt->close();

$pageTitle = $isSelf ? 'My Profile' : 'User Profile';
include 'forum_header.php';
?>

<div class="card">
    <div class="row-between" style="align-items:flex-start;">
        <div>
            <h1 style="margin:0 0 8px;">
                <?= h($user['nickname'] ?: $user['username']) ?>
            </h1>
            <div class="meta">
                @<?= h($user['username']) ?>
                <?php if (!empty($user['student_level'])): ?>
                    &middot; <?= h($user['student_level']) ?>
                <?php endif; ?>
            </div>

            <?php if ($isSelf): ?>
                <div class="meta">This is your community profile.</div>
            <?php else: ?>
                <?php if ($isFriend): ?>
                    <div class="alert alert-info" style="margin-top:12px; margin-bottom:0;">
                        You and this user are friends.
                    </div>
                <?php elseif ($isFollowing): ?>
                    <div class="meta" style="margin-top:10px;">You are following this user.</div>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <?php if (!$isSelf): ?>
            <div style="display:flex; gap:10px; flex-wrap:wrap; justify-content:flex-end;">
                <?php if ($isFollowing): ?>
                    <a class="btn btn-secondary" href="forum_follow_action.php?user_id=<?= $userId ?>&action=unfollow">
                        Unfollow
                    </a>
                <?php else: ?>
                    <a class="btn btn-primary" href="forum_follow_action.php?user_id=<?= $userId ?>&action=follow">
                        Follow
                    </a>
                <?php endif; ?>

                <a class="btn btn-dark" href="forum_inbox.php?user_id=<?= $userId ?>">
                    Message
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="card">
    <div class="row-between">
        <div style="flex:1; min-width:160px;">
            <div style="font-size:26px; font-weight:700; color:#1b4332;"><?= $followersCount ?></div>
            <div class="meta" style="margin:0;">Followers</div>
        </div>

        <div style="flex:1; min-width:160px;">
            <div style="font-size:26px; font-weight:700; color:#1b4332;"><?= $followingCount ?></div>
            <div class="meta" style="margin:0;">Following</div>
        </div>

        <div style="flex:1; min-width:160px;">
            <div style="font-size:26px; font-weight:700; color:#1b4332;"><?= $friendsCount ?></div>
            <div class="meta" style="margin:0;">Friends</div>
        </div>
    </div>

    <div style="margin-top:18px; display:flex; gap:10px; flex-wrap:wrap;">
        <a class="btn btn-secondary" href="forum_following.php?user_id=<?= $userId ?>">
            Following & Followers
        </a>
        <a class="btn btn-secondary" href="forum_friends.php">
            Friends
        </a>
    </div>
</div>

<div class="card">
    <div class="row-between">
        <h2 style="margin:0;">
            <?= $isSelf ? 'My Posts' : h($user['nickname'] ?: $user['username']) . '\'s Posts' ?>
        </h2>

        <?php if ($isSelf): ?>
            <a class="btn btn-primary" href="forum_post_create.php">New Post</a>
        <?php endif; ?>
    </div>
</div>

<?php if (empty($posts)): ?>
    <div class="card">
        <div class="meta" style="margin:0;">
            <?= $isSelf ? 'You have not posted anything yet.' : 'No visible posts from this user yet.' ?>
        </div>
    </div>
<?php endif; ?>

<?php foreach ($posts as $post): ?>
    <div class="card">
        <div class="row-between">
            <div>
                <h3 style="margin:0 0 8px;">
                    <a href="forum_post_view.php?post_id=<?= (int)$post['post_id'] ?>" style="text-decoration:none; color:#111827;">
                        <?= h($post['title'] ?: 'Untitled Post') ?>
                    </a>
                </h3>
                <div class="meta">
                    <?= h($post['visibility']) ?> &middot; <?= h($post['created_at']) ?>
                </div>
            </div>

            <?php if ((int)$post['user_id'] === $viewerId): ?>
                <a class="btn btn-danger" href="forum_delete_post.php?post_id=<?= (int)$post['post_id'] ?>">
                    Delete
                </a>
            <?php endif; ?>
        </div>

        <div class="post-content">
            <?= h(mb_substr($post['content'], 0, 260)) ?>
            <?= mb_strlen($post['content']) > 260 ? '...' : '' ?>
        </div>
    </div>
<?php endforeach; ?>

<?php include 'forum_footer.php'; ?>
